# Scrum Trello: 
[https://trello.com/invite/b/6810d3d1602225d5f48a208f/ATTI27631e16176ac542c43ff0aa91fcae00DB35531D/kid-s-basic-calculation-games]
/
(https://trello.com/b/ssL6YpJV)

# Anggota : 
1. Fauzi Farhansyah
2. Reffi Firdaus
3. Rijal Al Ihsan

# Kid-s-Basic-Calculation-Games
Aplikasi ini adalah permainan matematika sederhana untuk anak-anak, membantu mereka belajar operasi dasar (penjumlahan, pengurangan, perkalian, pembagian) dengan cara yang menyenangkan.

# 📖 Storyboard
Storyboard berikut menjelaskan alur penggunaan aplikasi Kids Math Game:

1. Halaman Splash / Awal
Menampilkan logo dan nama aplikasi.
Arahkan pengguna ke menu utama secara otomatis setelah beberapa detik.

2. Menu Utama
Terdapat pilihan:
Play Game: Masuk ke permainan matematika.
Settings: Mengatur tingkat kesulitan dan preferensi lainnya.
Exit: Keluar dari aplikasi.

3. Halaman Pilih Mode
Pengguna memilih jenis operasi matematika:
Penjumlahan
Pengurangan
Perkalian
Pembagian

4. Halaman Permainan
Pertanyaan matematika ditampilkan.
Pengguna memilih jawaban dari beberapa opsi.
Nilai dan waktu ditampilkan.

5. Hasil / Skor
Menampilkan skor akhir setelah permainan selesai.
Terdapat opsi untuk bermain ulang atau kembali ke menu utama.
