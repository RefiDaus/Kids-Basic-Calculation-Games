📖 Storyboard
Storyboard berikut menjelaskan alur penggunaan aplikasi Kids Math Game:

Halaman Splash / Awal

Menampilkan logo dan nama aplikasi.

Arahkan pengguna ke menu utama secara otomatis setelah beberapa detik.

Menu Utama

Terdapat pilihan:

Play Game: Masuk ke permainan matematika.

Settings: Mengatur tingkat kesulitan dan preferensi lainnya.

Exit: Keluar dari aplikasi.

Halaman Pilih Mode

Pengguna memilih jenis operasi matematika:

Penjumlahan

Pengurangan

Perkalian

Pembagian

Halaman Permainan

Pertanyaan matematika ditampilkan.

Pengguna memilih jawaban dari beberapa opsi.

Nilai dan waktu ditampilkan.

Hasil / Skor

Menampilkan skor akhir setelah permainan selesai.

Terdapat opsi untuk bermain ulang atau kembali ke menu utama.